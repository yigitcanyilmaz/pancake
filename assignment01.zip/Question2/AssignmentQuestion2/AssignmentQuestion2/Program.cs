﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentQuestion2
{
    internal class Program
    {
        static int power(int x, int y)
        {
            if (y == 0)
                return 1;
            else if (y % 2 == 0)
                return power(x, y / 2) * power(x, y / 2);
            else
                return x * power(x, y / 2) * power(x, y / 2);
        }
        static void Main(string[] args)
        {
            // Don't forget: x^y 
            int x = 2;
            int y = 0;

            Console.Write(power(x, y));
        }
    }
}
