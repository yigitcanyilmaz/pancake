﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentQuestion3
{
    internal class Program
    {
        static int CHAR_BIT = 8;

        
        static int min(int x, int y)
        {
            return y + ((x - y) & ((x - y) >>
                        (sizeof(int) * CHAR_BIT - 1)));
        }

        
        static int max(int x, int y)
        {
            return x - ((x - y) & ((x - y) >>
                    (sizeof(int) * CHAR_BIT - 1)));
        }
        static void Main(string[] args)
        {
            int x = 26;
            int y = 17;
            Console.WriteLine("Minimum is " + min(x, y));
            Console.WriteLine("Maximum is " + max(x, y));
        }
    }
}
